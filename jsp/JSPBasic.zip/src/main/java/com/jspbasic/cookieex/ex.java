package com.jspbasic.cookieex;

import java.util.Arrays;

public class ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] heroes = {"캡틴아메리카", "아이언맨", "헐크"};
		System.out.println(Arrays.toString(heroes));
		System.out.println(heroes[1]);
		System.out.println(heroes[4]);
	}

}
