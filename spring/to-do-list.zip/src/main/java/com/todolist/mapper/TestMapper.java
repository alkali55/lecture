package com.todolist.mapper;

public interface TestMapper {
	
	String selectNow();
	
}
