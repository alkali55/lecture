package com.goott5.lms.courseboardqna.mapper;

public class Mapper {
}
