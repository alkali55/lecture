package com.miniproj.exception;

public class CommentNotFoundException extends Exception {

    public CommentNotFoundException(String message) {
        super(message);
    }
}
