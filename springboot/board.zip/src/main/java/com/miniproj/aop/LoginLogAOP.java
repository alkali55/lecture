package com.miniproj.aop;


import com.miniproj.domain.LoginDTO;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Aspect
@Component
@Slf4j
/**
 * 유저의 로그인 기록 :
 * 로그인 시간, 멤버아이디, ip주소, 로그인 성공여부
 * C:/upload/logs/log_yyyyMMdd.csv
 */
public class LoginLogAOP {

    @Value("${file.upload-base-dir}")
    private String baseDir; // C:/upload/

    private String logDir;

    @PostConstruct // Spring에서 빈이 생성되고, 의존성 주입 직후 자동으로 실행시키는 메서드에 붙이는 어노테이션.
    public void makeLogDir(){
        this.logDir = baseDir + "logs";
    }

    @Around("execution(* com.miniproj.service.MemberServiceImpl.login(..))")
    public Object logLoginAttempt(ProceedingJoinPoint joinPoint) throws Throwable {

        log.info("------------ aop : 로그인 시도 감지 (Before) ------------");



        Object[] args = joinPoint.getArgs();

        if (args.length == 0 || !(args[0] instanceof LoginDTO)){
            log.warn("loginDTO 가 아님: {}", args[0]);
        }

        LoginDTO loginDTO = (LoginDTO) args[0];
        String memberId = loginDTO.getMemberId();
        String ipAddr = loginDTO.getIpAddr();
        String loginTime = LocalDateTime.now().toString();

        StringBuilder logContent = new StringBuilder();
        logContent.append(loginTime).append(",")
                .append(memberId).append(",")
                .append(ipAddr).append(",");

        log.info("로그인시도 정보 : {}, {}, {}", loginTime, memberId, ipAddr);

        // aop After
        Object result = joinPoint.proceed();

        log.info("result : {}", result);

        if(result == null){
            log.info("aop : 로그인 실패 = {}", memberId);
            logContent.append("login fail");
        } else {
            log.info("aop : 로그인 성공 = {}", memberId);
            logContent.append("login success");
        }


        log.info("aop : baseDir = {}", baseDir);
        log.info("aop : 로그저장경로 = {}", logDir);

        // 파일명 : log_yyyyMMdd.csv
        String yyyyMMdd = getDatePath();
        String fileName = "logs_" + yyyyMMdd + ".csv";


        writeLog(fileName, logContent.toString());

        return result; // target 메서드 수행 후 , 반환되는 값을 다시 컨트롤러 단으로 돌려 줌.
    }

    private void writeLog(String fileName, String content) {

        File dir = new File(logDir);

        if(!dir.exists()){
            dir.mkdirs();
        }

        File file = new File(dir, fileName);
        try(FileWriter fw = new FileWriter(file, true)) {
            fw.write(content + "\n");
            fw.flush();
        } catch (IOException e){
            log.error("aop : 로그인 로그 저장 실패", e);
        }
    }

    private String getDatePath(){
        LocalDate today = LocalDate.now();

        return today.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
    }
}
