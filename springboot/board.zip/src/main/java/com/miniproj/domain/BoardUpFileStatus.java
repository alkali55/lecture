package com.miniproj.domain;

public enum BoardUpFileStatus {

    INSERT, DELETE

}
