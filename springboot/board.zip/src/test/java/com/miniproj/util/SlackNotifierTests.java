package com.miniproj.util;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Slf4j
public class SlackNotifierTests {

    @Autowired
    private SlackNotifier slackNotifier;

    @Autowired
    private ApiSearchBlog apiSearchBlog;

    @Test
    public void testSendMessage () {

        slackNotifier.sendMessage("test title", "test message 보냅니다");

    }

    @Test
    public void testCallSearchBlog(){

        apiSearchBlog.callSearchBlog();
    }
}
