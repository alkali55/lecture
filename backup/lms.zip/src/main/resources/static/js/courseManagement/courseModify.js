const loginUserId = $('#login-user-id').val();
const loginUserType = $('#login-user-type').val();