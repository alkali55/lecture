// 1. 변수 선언 및 초기화
const loginUserId = $('#login-user-id').val();
const loginUserType = $('#login-user-type').val();

// 공통 설정 객체
const courseConfig = {
  pageNo: null,
  pageSize: null,
  type: null,
  keyword: null,
  orderBy: null,
  orderDirection: null,
};
const learnerConfig = {
  pageNo: null,
  pageSize: null,
  type: null,
  keyword: null,
  orderBy: null,
  orderDirection: null,
};

// 교육생 배정은 무조건 진행중인 과정에 대해서만 가능
let isInProgress =  1;



$(document).ready(() => {

  initCourseSelect();

  $('#course-select').on('change', handleCourseSelectChange);
  $('#search-button').on('click', handleSearchChange);
  $(document).on('keydown', '#search-input', function(e) {
    if (e.key == "Enter") {
      e.preventDefault();
      handleSearchChange();
    }
  });

  $(document).on('click', '.not-enrolled-add-button', handleAddEnrollment);
  $(document).on('click', '.enrolled-remove-button', handleRemoveEnrollment);
});




// 2. 초기화 함수
async function initCourseSelect() {

  let coursesWithPagination = await apiGetRequestAboutCourses(
    '/api/courses/all',
    {
      loginUserId: loginUserId,
      loginUserType: loginUserType,
      isInProgress: isInProgress});
  let courses = coursesWithPagination?.respDTOS || [];
  if (!Array.isArray(courses)) courses = [];

  updateSelectBox('#course-select', courses);

  // 첫 번째 옵션을 선택 상태로 변경
  $("#course-select option:eq(0)").prop("selected", true);
  // 이벤트 핸들러 강제 실행
  $("#course-select").trigger("change");
}

// 3. 이벤트 핸들러

async function handleCourseSelectChange() {
  // 검색창 초기화
  $('#search-input').val('');


  let { enrolledLearners, notEnrolledLearners} = await getLearnersByEnrollment();
  displayTables(enrolledLearners, notEnrolledLearners);
}

async function handleAddEnrollment() {
  let learnerId = $(this).data('id');
  let courseId = $("#course-select").val();

  // learner_enrollment 테이블에 courseId, learnerId를 추가
  let data = await apiPostRequest(
    '/api/learner-enrollments',
    { learnerId: Number(learnerId), courseId: Number(courseId) });
  console.log(data);

  let {enrolledLearners, notEnrolledLearners} = await getLearnersByEnrollment();
  displayTables(enrolledLearners, notEnrolledLearners);
}

async function handleRemoveEnrollment() {
  let learnerId = $(this).data('id');
  let courseId = $("#course-select").val();

  let data = await apiDeleteRequest(
    '/api/learner-enrollments',
    { learnerId: Number(learnerId), courseId: Number(courseId) });
  console.log(data);

  let {enrolledLearners, notEnrolledLearners} = await getLearnersByEnrollment();
  displayTables(enrolledLearners, notEnrolledLearners);
}


async function handleSearchChange() {
  learnerConfig.type = 'fullname';
  learnerConfig.keyword = $("#search-input").val();
  let { enrolledLearners, notEnrolledLearners} = await getLearnersByEnrollment();
  displayTables(enrolledLearners, notEnrolledLearners);
}


// 4. API 관련 함수





async function apiPostRequest(endpoint, payload = {}, additionalParams = {}) {
  try {
    const response = await axios.post(endpoint, payload);
    return response.data;
  } catch (error) {
    console.error(`${endpoint} POST 요청 오류:`, error);
    return [];
  }
}

async function apiDeleteRequest(endpoint, additionalParams = {}) {
  try {
    const response = await axios.delete(endpoint, {
      params: { ...learnerConfig, ...additionalParams }
    });
    return response.data;
  } catch (error) {
    console.error(`${endpoint} 요청 오류:`, error);
    return [];
  }
}

async function getLearnersByEnrollment() {
  let courseId = $('#course-select').val();
  let enrolledLearners = await apiGetRequestAboutLearners(
    '/api/learners/enrolled',
    { courseId: courseId });
  enrolledLearners =
    Array.isArray(enrolledLearners) ? enrolledLearners : [enrolledLearners];

  let notEnrolledLearners = await apiGetRequestAboutLearners(
    '/api/learners/not-enrolled');
  notEnrolledLearners =
    Array.isArray(notEnrolledLearners) ? notEnrolledLearners : [notEnrolledLearners];

  return { enrolledLearners, notEnrolledLearners };
}

// 기타 함수
function displayTables(enrolledLearners, notEnrolledLearners) {
  console.log(enrolledLearners, notEnrolledLearners);
  $('#enrolled-list').empty();
  enrolledLearners.forEach(function(learner) {
    let rowHtml = `
        <tr>
          <td class="text-center align-middle">
  ${
      learner.completionStatus == null ? '미배정' :
        learner.completionStatus === 'IN_PROGRESS' ? '교육생' :
          learner.completionStatus === 'COMPLETED' ? '수료생' :
            learner.completionStatus
    }
</td>
          <td class="text-center align-middle">${learner.fullname}</td>
          <td class="text-center align-middle">${learner.mobile}</td>
          <td class="text-center align-middle">
            <button class="btn btn-danger btn-icon-split btn-sm enrolled-remove-button" data-id="${learner.id}">
              <span class="text">삭제</span>
            </button>
          </td>
        </tr>
      `;
    $('#enrolled-list').append(rowHtml);
  });

  $('#not-enrolled-list').empty();
  notEnrolledLearners.forEach(function(learner) {
    let rowHtml = `
        <tr>
          <td class="text-center align-middle">
  ${
      learner.completionStatus == null ? '미배정' :
        learner.completionStatus === 'IN_PROGRESS' ? '교육생' :
          learner.completionStatus === 'COMPLETED' ? '수료생' :
            learner.completionStatus
    }
</td>
          <td class="text-center align-middle">${learner.fullname}</td>
          <td class="text-center align-middle">${learner.mobile}</td>
          <td class="text-center align-middle">
            <button class="btn btn-info btn-icon-split btn-sm not-enrolled-add-button" data-id="${learner.id}">
              <span class="text">추가</span>
            </button>
          </td>
        </tr>
      `;
    $('#not-enrolled-list').append(rowHtml);
  });
}

function updateSelectBox(selector, data) {
  const $select = $(selector).empty();
  data.forEach(course => {
    $select.append($('<option>').val(course.id).text(course.name));
  });
}

async function apiGetRequestAboutCourses(endpoint, additionalParams = {}) {
  try {
    const response = await axios.get(endpoint, {
      params: { ...courseConfig, ...additionalParams }
    });
    console.log(response.data);
    return response.data.data;
  } catch (error) {
    console.error(`${endpoint} 요청 오류:`, error);
    return [];
  }
}

async function apiGetRequestAboutLearners(endpoint, additionalParams = {}) {
  try {
    const response = await axios.get(endpoint, {
      params: { ...learnerConfig, ...additionalParams }
    });
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.error(`${endpoint} 요청 오류:`, error);
    return [];
  }
}



