const loginUserId = $('#login-user-id').val();
const loginUserType = $('#login-user-type').val();
let isInProgress =  '1';

const config = {
  pageNo: 1,
  pageSize: 10,
  type: "name",
  keyword: null,
  orderBy: "name",
  orderDirection: "ASC",
};

$(document).ready(function() {
  $("#course-select").val(isInProgress);
  fetchAndDisplayView();
  $('#is-in-progress').on('change', handleProgressStatusChange);
  $('#search-button').on('click', handleSearchChange);
  $(document).on('keydown', '#search-input', function(e) {
    if (e.key == "Enter") {
      e.preventDefault();
      handleSearchChange();
    }
  });
  $('#order-by').on('change', handleOrderByChange);
  $('#order-direction').on('change', handleOrderDirectionChange);
  $(document).on('click', '.page-link', handlePageBtnClick);
});

/* ----------------------------------------------------------------------------- */
/* ----------------------------------------------------------------------------- */
/* ----------------------------------------------------------------------------- */

async function fetchAndDisplayView() {

  let coursesWithPagination = await apiGetRequest(
    '/api/courses/all',
    {
      loginUserId: loginUserId,
      loginUserType: loginUserType,
      isInProgress: isInProgress});
  let courses = coursesWithPagination?.respDTOS || [];
  if (!Array.isArray(courses)) courses = [];
  renderCourseTable(courses);
  renderCoursePagination(coursesWithPagination);
}

async function apiGetRequest(endpoint, additionalParams = {}) {
  try {
    const response = await axios.get(endpoint, {
      params: { ...config, ...additionalParams }
    });
    console.log(response.data);
    return response.data.data;
  } catch (error) {
    console.error(`${endpoint} 요청 오류:`, error);
    return [];
  }
}

function renderCourseTable(courses) {
  $('#table-body').empty();
  courses.forEach(function(course) {
    let rowHtml = `
        <tr>
          <td class="text-center align-middle">${course.isInProgress ? '진행 중': '종료'}</td>
          <td class="title align-middle">
            <a href="/courseDetail?courseId=${course.id}">${course.name}</a></td>
          <td class="text-center align-middle">${course.startDate} ~ ${course.endDate}</td>
          <td class="text-center align-middle">${course.numberOfLearner}</td>
          <td class="text-center align-middle">${course.instructorFullname}</td>
          <td class="text-center align-middle">${course.classroomName}</td>
          <td class="text-center align-middle">
            <button class="btn btn-primary btn-icon-split btn-sm">
              <span class="text"><a href="/courseSchedule?courseId=${course.id}">조회</a></span>
            </button>
          </td>
        </tr>
      `;
    $('#table-body').append(rowHtml);
  });
}

function renderCoursePagination(data) {
  if(data.totalRecords == 0) {
    $("#course-pagination").html("");
    return;
  }
  let output = `<ul class="pagination justify-content-center" style="margin:20px 0">`;
  let prevPage = data.pageNo > 1 ? data.pageNo - 1 : 1;
  // 이전 버튼
  output += `
    <li class="page-item ${data.pageNo == 1? 'disabled': ''}">
      <a class="page-link page-btn" href="#" data-page="${prevPage}">이전</a>
    </li>`;
  // 페이지 번호 버튼
  for (let i = data.blockStartPage; i <= data.blockEndPage; i++) {
    let active = data.pageNo == i ? "active" : "";
    output += `
      <li class="page-item ${active}">
        <a class="page-link page-btn" href="#" data-page="${i}">${i}</a>
      </li>`;
  }
  // 다음 버튼
  let nextPage = data.pageNo < data.blockEndPage ? data.pageNo + 1 : data.lastPage;
  output += `
    <li class="page-item ${data.pageNo == data.lastPage ? 'disabled': ''}">
      <a class="page-link page-btn" href="#" data-page="${nextPage}">다음</a>
    </li></ul>`;
  $("#course-pagination").html(output);
}

/* ----------------------------------------------------------------------------- */
/* ----------------------------------------------------------------------------- */
/* ----------------------------------------------------------------------------- */

function handleProgressStatusChange() {
  isInProgress = $('#is-in-progress').val() === 'all' ? null : $('#is-in-progress').val();
  fetchAndDisplayView();
}

function handleOrderByChange() {
  config.orderBy = $(this).val();
  fetchAndDisplayView();
}

function handleOrderDirectionChange() {
  config.orderDirection = $(this).val();
  fetchAndDisplayView();
}

function handleSearchChange() {
  config.keyword = $("#search-input").val();
  isInProgress = null; // 전체에서 검색
  config.pageNo = 1; // 검색결과 1페이지 보여주기
  $("#is-in-progress").val('all');
  fetchAndDisplayView();
}

function handlePageBtnClick() {
  config.pageNo = $(this).data('page');
  fetchAndDisplayView();
}




















/*
function updateTable() {
  console.log("updateTable()");
  let id = $(this).val();

  if (!id) return;

  if (id == '0') {
    apiUrl = '/api/courses';
  } else {
    apiUrl = `/api/courses/${id}`;
  }

  axios.get(apiUrl)
    .then(function(response) {
      console.log(response);

      // 배열이면 그대로 반환, 배열 아니면 배열로 감싸서 반환
      let courses = Array.isArray(response.data) ? response.data : [response.data];

      $('#table-body').empty();

      courses.forEach(function(course) {
        let rowHtml = `
          <tr>
            <td class="text-center align-middle">${course.isInProgress ? '진행 중': '종료'}</td>
            <td class="title align-middle">
              <a th:href="@{/courseDetail(id=${course.id})}">${course.name}</a></td>
            <td class="text-center align-middle">${course.startDate} ~ ${course.endDate}</td>
            <td class="text-center align-middle">${course.numberOfLearner}</td>
            <td class="text-center align-middle">★김강사★</td>
            <td class="text-center align-middle">★5강의실★</td>
            <td class="text-center align-middle">
              <button class="btn btn-primary btn-icon-split btn-sm">
                <span class="text">★조회★</span>
              </button>
            </td>
          </tr>
        `;
        $('#table-body').append(rowHtml);
      });
    })
    .catch(function(error) {
      console.error('특정 과정 조회 오류:', error);
    });
}*/
