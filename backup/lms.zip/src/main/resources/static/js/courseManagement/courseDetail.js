const loginUserId = $('#login-user-id').val();
const loginUserType = $('#login-user-type').val();

$(document).ready(function() {
  $(document).on('click', '#remove-button', handleRemoveBtnClick);
});

function handleRemoveBtnClick() {
  console.log('remove button clicked');
}