package com.goott5.lms.coursemanagement.controller;

import com.goott5.lms.coursemanagement.domain.ApiResponse;
import com.goott5.lms.coursemanagement.domain.CourseReqDTO;
import com.goott5.lms.coursemanagement.domain.CourseRespDTO;
import com.goott5.lms.coursemanagement.domain.PageCourseReqDTO;
import com.goott5.lms.coursemanagement.domain.PageCourseRespDTO;
import com.goott5.lms.coursemanagement.service.CourseManagementService;
import com.goott5.lms.learnermanagement.domain.PageUserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserRespDTO;
import com.goott5.lms.user.domain.UserVO;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Slf4j
@Controller
@RequiredArgsConstructor
public class CourseManagementController {

  private final CourseManagementService courseManagementService;

  // 전체 과정 리스트 조회
  @GetMapping("api/courses/all")
  @ResponseBody
  public ResponseEntity<ApiResponse<PageCourseRespDTO<CourseRespDTO>>> getCoursesAll(
          @ModelAttribute PageCourseReqDTO<CourseReqDTO> pageCourseReqDTO,
          @RequestParam("loginUserId") Integer loginUserId,
          @RequestParam("loginUserType") String loginUserType,
          @RequestParam(value = "isInProgress", required = false) Boolean isInProgress
  ) {
    PageCourseRespDTO<CourseRespDTO> courses =
            courseManagementService.findCoursesAll(pageCourseReqDTO, loginUserId, loginUserType,
                    isInProgress);
    return ApiResponse.okResponse(200, "success", courses);
  }

  // 과정 상세 조회
  @GetMapping("api/course")
  @ResponseBody
  public ResponseEntity<ApiResponse<CourseRespDTO>> getCourse(
          @RequestParam("loginUserId") Integer loginUserId,
          @RequestParam("loginUserType") String loginUserType,
          @RequestParam("courseId") Integer courseId
  ) {
    CourseRespDTO course =
            courseManagementService.findCourse(loginUserId, loginUserType, courseId);

    return ApiResponse.okResponse(200, "success", course);
  }

  @GetMapping("/courseList")
  public String courseList() {
    return "courseManagement/courseList";
  }

  @GetMapping("/courseDetail")
  public String courseDetail(
          @RequestParam(value = "courseId", defaultValue = "-1") Integer courseId,
          Model model,
          HttpSession session
  ) {

    if (courseId == -1) {
      return "/courseManagement/courseList";
    }

    UserVO loginUser = (UserVO) session.getAttribute("loginUser");
    Integer loginUserId = Integer.valueOf(loginUser.getId());
    String loginUserType = loginUser.getType();
    CourseRespDTO course =
            courseManagementService.findCourse(loginUserId, loginUserType, courseId);
    model.addAttribute("course", course);
    return "/courseManagement/courseDetail";
  }

  @GetMapping("/courseModify")
  public String courseModify(
          @RequestParam(value = "courseId", defaultValue = "-1") Integer courseId,
          Model model,
          HttpSession session
  ) {

    if (courseId == -1) {
      return "/courseManagement/courseList";
    } // 추후수정

    UserVO loginUser = (UserVO) session.getAttribute("loginUser");
    Integer loginUserId = Integer.valueOf(loginUser.getId());
    String loginUserType = loginUser.getType();
    CourseRespDTO course =
            courseManagementService.findCourse(loginUserId, loginUserType, courseId);
    model.addAttribute("course", course);
    return "/courseManagement/courseModify";
  }

  @GetMapping("api/learners/enrolled")
  @ResponseBody
  public List<UserRespDTO> getEnrolledLearnersByCourseId(
          @ModelAttribute PageUserReqDTO<UserReqDTO> pageUserReqDTO,
          @RequestParam("courseId") Integer courseId) {

    log.info("Controller: pageUserReqDTO:{}", pageUserReqDTO);

    return courseManagementService.findEnrolledLearnersByCourseId(pageUserReqDTO, courseId);

  }

  @GetMapping("api/learners/not-enrolled")
  @ResponseBody
  public List<UserRespDTO> getNotEnrolledLearners(
          @ModelAttribute PageUserReqDTO<UserReqDTO> pageUserReqDTO
  ) {

    log.info("Controller: pageUserReqDTO:{}", pageUserReqDTO);

    return courseManagementService.findNotEnrolledLearnersAll(pageUserReqDTO);

  }

  @PostMapping("api/learner-enrollments")
  @ResponseBody
  public ResponseEntity<ApiResponse<Void>> enrollLearners(
          @RequestBody Map<String, Object> payload) {

    boolean isSuccess =
            courseManagementService.enrollLearnerToCourse(
                    (Integer) payload.get("learnerId"),
                    (Integer) payload.get("courseId")
            );

    if (isSuccess) {
      return ApiResponse.okResponse(200, "등록 성공", null);
    }
    {
      return ApiResponse.okResponse(400, "등록 실패", null);
    }
  }

  @DeleteMapping("api/learner-enrollments")
  @ResponseBody
  public ResponseEntity<ApiResponse<Void>> unenrollLearners(
          @RequestParam("learnerId") Integer learnerId,
          @RequestParam("courseId") Integer courseId
  ) {
    boolean isSuccess = courseManagementService.unenrollLearnerToCourse(learnerId, courseId);

    if (isSuccess) {
      return ApiResponse.okResponse(200, "등록 성공", null);
    }
    {
      return ApiResponse.okResponse(400, "등록 실패", null);
    }
  }


  @GetMapping("/learnerAssignment")
  public String learnerAssignment(HttpSession session, Model model) {
    model.addAttribute("loginUser", session.getAttribute("loginUser"));

    return "/courseManagement/learnerAssignment";
  }


}
