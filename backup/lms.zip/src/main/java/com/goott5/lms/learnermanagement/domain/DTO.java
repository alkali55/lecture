package com.goott5.lms.learnermanagement.domain;

public class DTO {
}
