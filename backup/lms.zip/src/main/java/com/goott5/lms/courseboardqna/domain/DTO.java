package com.goott5.lms.courseboardqna.domain;

public class DTO {
}
