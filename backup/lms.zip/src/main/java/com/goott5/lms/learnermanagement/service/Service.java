package com.goott5.lms.learnermanagement.service;

public class Service {
}
