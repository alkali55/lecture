package com.goott5.lms.learnermanagement.mapper;

public class Mapper {
}
