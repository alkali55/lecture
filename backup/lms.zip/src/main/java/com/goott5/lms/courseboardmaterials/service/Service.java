package com.goott5.lms.courseboardmaterials.service;

public class Service {
}
