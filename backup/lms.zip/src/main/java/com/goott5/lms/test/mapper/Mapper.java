package com.goott5.lms.test.mapper;

public class Mapper {
}
