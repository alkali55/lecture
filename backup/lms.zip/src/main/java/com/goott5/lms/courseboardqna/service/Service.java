package com.goott5.lms.courseboardqna.service;

public class Service {
}
