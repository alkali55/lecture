package com.goott5.lms.learnermanagement.service;

import com.goott5.lms.coursemanagement.mapper.CourseManagementMapper;
import com.goott5.lms.learnermanagement.domain.PageUserReqDTO;
import com.goott5.lms.learnermanagement.domain.PageUserRespDTO;
import com.goott5.lms.learnermanagement.domain.UserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserRespDTO;
import com.goott5.lms.learnermanagement.mapper.LearnerManagementMapper;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class LearnerManagementServiceImpl implements LearnerManagementService {

  private final LearnerManagementMapper learnerManagementMapper;
  private final CourseManagementMapper courseManagementMapper;

  @Override
  public PageUserRespDTO<UserRespDTO> findLearnersAll(
          PageUserReqDTO<UserReqDTO> pageUserReqDTO,
          Integer loginUserId,
          String loginUserType,
          Integer courseId,
          Boolean isInProgress
  ) {
    Integer originalPageNo = pageUserReqDTO.getPageNo();
    Integer originalPageSize = pageUserReqDTO.getPageSize();

    if (originalPageNo != null && originalPageSize != null) {
      pageUserReqDTO.setPageNo(null);
      pageUserReqDTO.setPageSize(null);
    }

    List<UserRespDTO> learnersAll = learnerManagementMapper.selectLearnersAll(
            pageUserReqDTO, loginUserId, loginUserType, courseId, isInProgress);
    int totalRecords = learnersAll.size();

    if (originalPageNo != null && originalPageSize != null) {
      pageUserReqDTO.setPageNo(originalPageNo);
      pageUserReqDTO.setPageSize(originalPageSize);
      // 페이징된 데이터만 조회
      learnersAll = learnerManagementMapper.selectLearnersAll(
              pageUserReqDTO, loginUserId, loginUserType, courseId, isInProgress);
    }

    return PageUserRespDTO.<UserRespDTO>withPageInfo()
            .pageUserReqDTO(pageUserReqDTO)
            .totalRecords(totalRecords)
            .respDTOS(learnersAll)
            .build();
  }
}
