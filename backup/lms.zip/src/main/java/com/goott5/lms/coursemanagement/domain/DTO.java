package com.goott5.lms.coursemanagement.domain;

public class DTO {
}
