package com.goott5.lms.coursemanagement.service;

import com.goott5.lms.coursemanagement.domain.CourseReqDTO;
import com.goott5.lms.coursemanagement.domain.CourseRespDTO;
import com.goott5.lms.coursemanagement.domain.PageCourseReqDTO;
import com.goott5.lms.coursemanagement.domain.PageCourseRespDTO;
import com.goott5.lms.coursemanagement.mapper.CourseManagementMapper;
import com.goott5.lms.learnermanagement.domain.PageUserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserRespDTO;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class CourseManagementServiceImpl implements CourseManagementService {

  private final CourseManagementMapper courseManagementMapper;

  @Override
  public List<UserRespDTO> findEnrolledLearnersByCourseId(
          PageUserReqDTO<UserReqDTO> pageUserReqDTO,
          Integer courseId
  ) {

    List<UserRespDTO> userRespDTOS =
            courseManagementMapper.selectEnrolledLearnersByCourseId(pageUserReqDTO, courseId);

    return userRespDTOS;
  }

  @Override
  public List<UserRespDTO> findNotEnrolledLearnersAll(
          PageUserReqDTO<UserReqDTO> pageUserReqDTO
  ) {

    List<UserRespDTO> userRespDTOS =
            courseManagementMapper.selectNotEnrolledLearnersAll(pageUserReqDTO);

    return userRespDTOS;
  }

  @Override
  public boolean enrollLearnerToCourse(Integer learnerId, Integer courseId) {
    int result = courseManagementMapper.insertEnrollLearnerToCourse(learnerId, courseId);

    return result > 0;
  }

  @Override
  public boolean unenrollLearnerToCourse(Integer learnerId, Integer courseId) {
    int result = courseManagementMapper.deleteEnrollLearnerToCourse(learnerId, courseId);

    return result > 0;
  }


  @Override
  public PageCourseRespDTO<CourseRespDTO> findCoursesAll(
          PageCourseReqDTO<CourseReqDTO> pageCourseReqDTO,
          Integer loginUserId,
          String loginUserType,
          Boolean isInProgress) {

    Integer originalPageNo = pageCourseReqDTO.getPageNo();
    Integer originalPageSize = pageCourseReqDTO.getPageSize();

    if (originalPageNo != null && originalPageSize != null) {
      pageCourseReqDTO.setPageNo(null);
      pageCourseReqDTO.setPageSize(null);
    }

    List<CourseRespDTO> allCourses = courseManagementMapper.selectCoursesAll(
            pageCourseReqDTO, loginUserId, loginUserType, isInProgress);
    int totalRecords = allCourses.size();

    if (originalPageNo != null && originalPageSize != null) {
      pageCourseReqDTO.setPageNo(originalPageNo);
      pageCourseReqDTO.setPageSize(originalPageSize);
      // 페이징된 데이터만 조회
      allCourses = courseManagementMapper.selectCoursesAll(
              pageCourseReqDTO, loginUserId, loginUserType, isInProgress);
    }

    if (!allCourses.isEmpty()) {
      for (CourseRespDTO courseRespDTO : allCourses) {
        String instructorFullname = courseManagementMapper.selectInstructorFullname(courseRespDTO);
        if (instructorFullname == null) {
          instructorFullname = "미배정";
        }
        courseRespDTO.setInstructorFullname(instructorFullname);
        String classroomName = courseManagementMapper.selectClassroomName(courseRespDTO);
        if (classroomName == null) {
          classroomName = "미배정";
        }
        courseRespDTO.setClassroomName(classroomName);
      }
    }

    return PageCourseRespDTO.<CourseRespDTO>withPageInfo()
            .pageCourseReqDTO(pageCourseReqDTO)
            .totalRecords(totalRecords)
            .respDTOS(allCourses)
            .build();
  }

  @Override
  public CourseRespDTO findCourse(
          Integer loginUserId,
          String loginUserType,
          Integer courseId
  ) {

    CourseRespDTO course =
            courseManagementMapper.selectCourse(loginUserId, loginUserType, courseId);

    if (course != null) {
      String instructorFullname = courseManagementMapper.selectInstructorFullname(course);
      if (instructorFullname == null) {
        instructorFullname = "미배정";
      }
      course.setInstructorFullname(instructorFullname);
      String classroomName = courseManagementMapper.selectClassroomName(course);
      if (classroomName == null) {
        classroomName = "미배정";
      }
      course.setClassroomName(classroomName);
      course.setSubjects(courseManagementMapper.selectCourseSubjectById(courseId));
    }

    return course;
  }
}
