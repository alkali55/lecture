package com.goott5.lms.coursemanagement.mapper;

import com.goott5.lms.coursemanagement.domain.CourseReqDTO;
import com.goott5.lms.coursemanagement.domain.CourseRespDTO;
import com.goott5.lms.coursemanagement.domain.CourseSubjectRespDTO;
import com.goott5.lms.coursemanagement.domain.PageCourseReqDTO;
import com.goott5.lms.coursemanagement.domain.PageListReqDTO;
import com.goott5.lms.learnermanagement.domain.PageUserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserRespDTO;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface CourseManagementMapper {


  Integer selectCourseCount(
          @Param("pageListReqDTO") PageListReqDTO<CourseReqDTO> pageListReqDTO,
          @Param("userId") Integer userId,
          @Param("isInProgress") Boolean isInProgress);

  List<CourseRespDTO> selectCoursesByCondition(
          @Param("pageListReqDTO") PageListReqDTO<CourseReqDTO> pageListReqDTO,
          @Param("userId") Integer userId,
          @Param("isInProgress") Boolean isInProgress);

/*  @Select("SELECT * FROM course WHERE is_in_progress = #{isInProgress}")
  List<CourseRespDTO> selectCourseListByProgressStatus(Boolean isInProgress);

  @Select("SELECT * FROM course WHERE id = #{id}")
  CourseRespDTO selectCourseById(Long id);*/

  // ------------------------------------------------------------------

  List<UserRespDTO> selectEnrolledLearnersByCourseId(
          @Param("pageUserReqDTO") PageUserReqDTO<UserReqDTO> pageUserReqDTO,
          @Param("courseId") Integer courseId
  );

  List<UserRespDTO> selectNotEnrolledLearnersAll(
          @Param("pageUserReqDTO") PageUserReqDTO<UserReqDTO> pageUserReqDTO
  );

  @Insert("INSERT INTO learner_enrollment (user_id, course_id) VALUES (#{userId}, #{courseId})")
  int insertEnrollLearnerToCourse(
          @Param("userId") Integer userId,
          @Param("courseId") Integer courseId
  );

  @Delete("DELETE FROM learner_enrollment WHERE user_id = #{userId} AND course_id = #{courseId}")
  int deleteEnrollLearnerToCourse(
          @Param("userId") Integer userId,
          @Param("courseId") Integer courseId
  );


  // CourseManagementMapper.xml에 추가
  List<CourseRespDTO> selectCoursesAll(
          PageCourseReqDTO<CourseReqDTO> pageCourseReqDTO,
          Integer loginUserId,
          String loginUserType,
          Boolean isInProgress);

  // CourseManagementMapper.xml에 추가
  CourseRespDTO selectCourse(
          Integer loginUserId, String loginUserType, Integer courseId);

  @Select({
          "SELECT fullname FROM user",
          "WHERE id in (",
          "  SELECT user_id FROM staff_assignment",
          "    WHERE course_id = #{courseRespDTO.id}) AND type = 'INSTRUCTOR'"
  })
  String selectInstructorFullname(@Param("courseRespDTO") CourseRespDTO courseRespDTO);

  @Select({
          "SELECT name FROM classroom",
          "WHERE id in (",
          "  SELECT classroom_id FROM classroom_allocation",
          "    WHERE course_id = #{courseRespDTO.id})"
  })
  String selectClassroomName(@Param("courseRespDTO") CourseRespDTO courseRespDTO);

  @Select({
          "SELECT * FROM course_subject",
          "WHERE course_id = #{courseId} ORDER BY subject_order ASC"})
  List<CourseSubjectRespDTO> selectCourseSubjectById(Integer courseId);
}
