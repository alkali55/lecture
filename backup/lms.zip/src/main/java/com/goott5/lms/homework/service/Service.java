package com.goott5.lms.homework.service;

public class Service {
}
