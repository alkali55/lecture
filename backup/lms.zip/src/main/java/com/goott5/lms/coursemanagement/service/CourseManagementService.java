package com.goott5.lms.coursemanagement.service;

import com.goott5.lms.coursemanagement.domain.CourseReqDTO;
import com.goott5.lms.coursemanagement.domain.CourseRespDTO;
import com.goott5.lms.coursemanagement.domain.PageCourseReqDTO;
import com.goott5.lms.coursemanagement.domain.PageCourseRespDTO;
import com.goott5.lms.learnermanagement.domain.PageUserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserRespDTO;
import java.util.List;

public interface CourseManagementService {

  /*PageListRespDTO<CourseRespDTO> findCourses(
    PageListReqDTO<CourseReqDTO> pageListReqDTO,
    Integer userId,
    Boolean isInProgress
  );*/

  CourseRespDTO findCourse(Integer loginUserId, String loginUserType, Integer courseId);


  List<UserRespDTO> findEnrolledLearnersByCourseId(PageUserReqDTO<UserReqDTO> pageUserReqDTO,
          Integer courseId);

  List<UserRespDTO> findNotEnrolledLearnersAll(PageUserReqDTO<UserReqDTO> pageUserReqDTO);

  boolean enrollLearnerToCourse(Integer learnerId, Integer courseId);

  boolean unenrollLearnerToCourse(Integer learnerId, Integer courseId);

  PageCourseRespDTO<CourseRespDTO> findCoursesAll(
          PageCourseReqDTO<CourseReqDTO> pageCourseReqDTO,
          Integer loginUserId,
          String loginUserType,
          Boolean isInProgress);

}
