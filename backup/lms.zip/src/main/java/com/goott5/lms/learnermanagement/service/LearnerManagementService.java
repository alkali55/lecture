package com.goott5.lms.learnermanagement.service;

import com.goott5.lms.learnermanagement.domain.PageUserReqDTO;
import com.goott5.lms.learnermanagement.domain.PageUserRespDTO;
import com.goott5.lms.learnermanagement.domain.UserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserRespDTO;

public interface LearnerManagementService {

  PageUserRespDTO<UserRespDTO> findLearnersAll(
          PageUserReqDTO<UserReqDTO> pageUserReqDTO,
          Integer loginUserId,
          String loginUserType,
          Integer courseId,
          Boolean isInProgress
  );
}
