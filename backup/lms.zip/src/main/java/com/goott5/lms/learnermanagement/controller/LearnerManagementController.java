package com.goott5.lms.learnermanagement.controller;

import com.goott5.lms.learnermanagement.domain.PageUserReqDTO;
import com.goott5.lms.learnermanagement.domain.PageUserRespDTO;
import com.goott5.lms.learnermanagement.domain.UserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserRespDTO;
import com.goott5.lms.learnermanagement.service.LearnerManagementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@Slf4j
@RequiredArgsConstructor
public class LearnerManagementController {

  private final LearnerManagementService learnerManagementService;

  // 전체 교육생 수강 조회
  @GetMapping("api/learners/all")
  @ResponseBody // value = "courseId", required = false
  public PageUserRespDTO<UserRespDTO> getLearnersAll(
          @ModelAttribute PageUserReqDTO<UserReqDTO> pageUserReqDTO,
          @RequestParam("loginUserId") Integer loginUserId,
          @RequestParam("loginUserType") String loginUserType,
          @RequestParam(value = "courseId", required = false) Integer courseId,
          @RequestParam(value = "isInProgress", required = false) Boolean isInProgress) {

    log.info("loginUserId: " + loginUserId);
    log.info("loginUserType: " + loginUserType);
    log.info("courseId: " + courseId);
    log.info("isInProgress: " + isInProgress);
    return learnerManagementService.findLearnersAll(pageUserReqDTO, loginUserId, loginUserType,
            courseId, isInProgress);
  }

  @GetMapping("/learnerList")
  public String learnerList() {
    return "/learnerManagement/learnerList";
  }






  /*@GetMapping("api/users")
  @ResponseBody
  public PageListRespDTO<UserRespDTO> getUserList(
    @RequestParam(required = false) Integer courseId,
    @RequestParam(required = false) Integer userId,
    @RequestParam(defaultValue = "1") Integer pageNo,
    @RequestParam(defaultValue = "10") Integer pageSize,
    @RequestParam(required = false) String type,
    @RequestParam(required = false) String keyword,
    @RequestParam(required = false) String orderBy,
    @RequestParam(required = false) String orderDirection
  ){

    *//*PageListReqDTO<UserReqDTO> pageListReqDTO = PageListReqDTO.<UserReqDTO>builder()
      .id(userId)
      .pageNo(pageNo)
      .pageSize(pageSize)
      .orderBy(orderBy)
      .orderDirection(orderDirection)
      .build();

    log.info("pageListReqDTO: {}", pageListReqDTO);*//*
    PageListRespDTO<UserRespDTO> pageListRespDTO = null; //.findUsers(courseId, pageListReqDTO);
    log.info("pageListRespDTO: {}", pageListRespDTO);
    return pageListRespDTO;
  }*/
}
