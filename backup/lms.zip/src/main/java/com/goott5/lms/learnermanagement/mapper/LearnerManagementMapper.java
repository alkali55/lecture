package com.goott5.lms.learnermanagement.mapper;

import com.goott5.lms.coursemanagement.domain.PageListReqDTO;
import com.goott5.lms.learnermanagement.domain.PageUserReqDTO;
import com.goott5.lms.learnermanagement.domain.UserRespDTO;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface LearnerManagementMapper {

  List<UserRespDTO> selectLearnersByCondition(
          @Param("pageListReqDTO") PageListReqDTO pageListReqDTO,
          @Param("userId") Integer userId,
          @Param("courseId") Integer courseId,
          @Param("isInProgress") Boolean isInProgress);

  // LearnerManagementMapper.xml에 추가
  List<UserRespDTO> selectLearnersAll(
          @Param("pageUserReqDTO") PageUserReqDTO pageUserReqDTO,
          @Param("loginUserId") Integer loginUserId,
          @Param("loginUserType") String loginUserType,
          @Param("courseId") Integer courseId,
          @Param("isInProgress") Boolean isInProgress
  );
}
