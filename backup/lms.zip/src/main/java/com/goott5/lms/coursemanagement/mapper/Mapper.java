package com.goott5.lms.coursemanagement.mapper;

public class Mapper {
}
