package com.goott5.lms.test.domain;

public class DTO {
}
