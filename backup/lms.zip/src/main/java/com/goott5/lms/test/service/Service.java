package com.goott5.lms.test.service;

public class Service {
}
