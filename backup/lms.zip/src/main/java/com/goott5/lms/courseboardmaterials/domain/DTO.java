package com.goott5.lms.courseboardmaterials.domain;

public class DTO {
}
