package com.goott5.lms.homework.domain;

public class DTO {
}
