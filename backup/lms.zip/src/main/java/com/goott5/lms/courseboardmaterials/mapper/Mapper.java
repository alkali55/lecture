package com.goott5.lms.courseboardmaterials.mapper;

public class Mapper {
}
